package com.tericcabrel.authorization.services.interfaces;

public interface PermissionLoader {
  void load();
}
